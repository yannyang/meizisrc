package sundy.gesture;

import java.util.ArrayList;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.gesture.Gesture;
import android.gesture.GestureLibraries;
import android.gesture.GestureLibrary;
import android.gesture.GestureOverlayView;
import android.gesture.Prediction;
import android.gesture.GestureOverlayView.OnGesturePerformedListener;
import android.widget.Toast;

/**
 * @author Administrator
 *
 */
public class ActivityManagerActivity {

	private static int index = 1; 
	
	public static void recongize(Context curContext,GestureLibrary mGestureLibrary , Gesture arg1)
	{
		ArrayList<Prediction> predictions = mGestureLibrary.recognize(arg1)  ;
		if(predictions.size() >0)
		{
			Prediction prediction = predictions.get(0) ;
			//����
			if(prediction.score > 5.0)
			{
				Toast.makeText(curContext, prediction.name, 3000).show()  ;
				if(prediction.name.equals("next"))
				{
					switch (index) {
					case 1:
						curContext.startActivity(new Intent(curContext,GestureActivity2.class))  ;
						++ index ;
						break ;
					case 2:
						curContext.startActivity(new Intent(curContext,GestureActivity3.class))  ;
						++ index ;
						break ;
					case 3:
						curContext.startActivity(new Intent(curContext,GestureActivity4.class))  ;
						++ index ;
						break ;
					case 4:
						curContext.startActivity(new Intent(curContext,GestureActivity1.class))  ;
						index = 1 ;
						break;

					default:
						break;
					}
					
					
				}else if(prediction.name.equals("end"))
					curContext.startActivity(new Intent(curContext,GestureActivity4.class))  ;
				else if(prediction.name.equals("first"))
					curContext.startActivity(new Intent(curContext,GestureActivity1.class))  ;
				else if(prediction.name.equals("prev"))
				{
					
				}
				else if(prediction.name.equals("create"))
				{
					curContext.startActivity(new Intent(curContext,GestureCreateActivity.class))  ;
				}
			}
		}
	}
}
