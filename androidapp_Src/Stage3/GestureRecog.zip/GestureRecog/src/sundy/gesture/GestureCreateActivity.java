package sundy.gesture;

import android.app.Activity;
import android.gesture.Gesture;
import android.gesture.GestureLibraries;
import android.gesture.GestureLibrary;
import android.gesture.GestureOverlayView;
import android.gesture.GestureOverlayView.OnGesturePerformedListener;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class GestureCreateActivity extends Activity {
	private GestureLibrary mGestureLibrary  ;
	private Gesture mGesture  ;
	private EditText editText ;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.creategesture)  ;
		editText = (EditText)findViewById(R.id.editTextName)  ;
		Button buttonCreate = (Button)findViewById(R.id.buttonCreateGesture)  ;
		
		
		//1,���ƿ�ļ���
        mGestureLibrary = GestureLibraries.fromFile("/sdcard/gestures")  ;
        if(!mGestureLibrary.load())
        	finish()  ;
        
        //2,��viewȥ��������
        GestureOverlayView goView = (GestureOverlayView)findViewById(R.id.gestureOverlayViewCreate)  ;
        goView.addOnGesturePerformedListener(new OnGesturePerformedListener() {
			
			@Override
			public void onGesturePerformed(GestureOverlayView arg0, Gesture arg1) {
				// TODO Auto-generated method stub
				if(arg1 != null)
				{
					mGesture = arg1  ;
				}
			}
		}) ;
		
        buttonCreate.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if(mGesture != null)
				{
					mGestureLibrary.addGesture(editText.getText().toString(), mGesture)  ;
					mGestureLibrary.save()  ;
					Toast.makeText(GestureCreateActivity.this, "��������:"+editText.getText().toString(), 3000) ;
				}
				
			}
		})  ;
		
		
		
	}

}
