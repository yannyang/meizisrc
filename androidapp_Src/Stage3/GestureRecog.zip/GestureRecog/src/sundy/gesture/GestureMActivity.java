package sundy.gesture;

import android.app.Activity;
import android.gesture.Gesture;
import android.gesture.GestureLibraries;
import android.gesture.GestureLibrary;
import android.gesture.GestureOverlayView;
import android.gesture.GestureOverlayView.OnGesturePerformedListener;
import android.os.Bundle;
import android.widget.ImageView;

public class GestureMActivity extends Activity {

	private GestureLibrary mGestureLibrary  ;
	
	private int index = 0  ;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gesturemanage);
        
        /*ImageView imageView1 = (ImageView)findViewById(R.id.imageView1)  ;
        
        
        imageView1.setImageDrawable(R.drawable.)
        
        //1,���ƿ�ļ���
        mGestureLibrary = GestureLibraries.fromRawResource(this, R.raw.gestures);
        if(!mGestureLibrary.load())
        	finish()  ;
        
        //2,��viewȥ��������
        GestureOverlayView goView = (GestureOverlayView)findViewById(R.id.gestureOverlayView1)  ;
        goView.addOnGesturePerformedListener(new OnGesturePerformedListener() {
			
			@Override
			public void onGesturePerformed(GestureOverlayView arg0, Gesture arg1) {
				// TODO Auto-generated method stub
				//3,ʶ��ƥ�䣩����
			
				ActivityManagerActivity.recongize(GestureActivity1.this, mGestureLibrary, arg1)  ;
			}
		}) ;*/
    }
}
