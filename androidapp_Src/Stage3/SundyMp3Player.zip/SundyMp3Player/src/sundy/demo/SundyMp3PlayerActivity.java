package sundy.demo;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import android.R.string;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.SimpleAdapter;

public class SundyMp3PlayerActivity extends Activity {
    /** Called when the activity is first created. */
	private final String MUSIC_PATH = "/sdcard/sundymusic/" ;
	private ImageButton imageButtonPlay  ;
	private ImageButton imageButtonPrev  ;
	private ImageButton imageButtonNext  ;
	private ListView mListView ;
	private SeekBar mSeekBar  ;
	private PlayerControl playerControl  ;
	private NotificationManager notificationManager ;
	
	private int mMusicIndex = 0 ;
	
	private List<String> mMusicList = new ArrayList<String>();
	private Handler mHandler ;
	
	private Timer mTimer ;
	//ʱ������
	private TimerTask mTimerTask  ;
	
	
	private void updateNotifycation()
	{
		// ����һ��NotificationManager������
        notificationManager = (NotificationManager) 
        		this.getSystemService(android.content.Context.NOTIFICATION_SERVICE);
		// assign the song name to songName
		PendingIntent pi = PendingIntent.getActivity(getApplicationContext(), 0,this.getIntent() , PendingIntent.FLAG_UPDATE_CURRENT);
		Notification notification = new Notification();
		notification.tickerText = "ǰ̨����";
		notification.icon = R.drawable.icon;
		notification.flags |= Notification.FLAG_ONGOING_EVENT;
		notification.setLatestEventInfo(getApplicationContext(), "Sundy���ֲ�����","���ڲ���...... ", pi);
		// ��Notification���ݸ�NotificationManager
        notificationManager.notify(123, notification);
	}
	
    @Override
	protected void onStart() {
		// TODO Auto-generated method stub
    	if(notificationManager != null)
    	{
    		notificationManager.cancel(123) ;
    	}
		super.onStart();
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		if(playerControl != null)
		{
			Log.i("sundy", "stoped")  ;
			updateNotifycation() ;
			
		}
		super.onStop();
	}
	
	class MusicFilter implements FilenameFilter
	{
		public boolean accept(File dir, String name)
		{
			// get *.mp3 file
			return (name.endsWith(".mp3"));
		}
	}
	
	
	/**
	 * �õ�/sdcard/sundymusic������mp3�ļ��б�
	 */
	private void getMusicList()
	{
		// get files on sdcard and show on main activity
		File music = new File(MUSIC_PATH);
		Log.i("Sundy", "��ʼ��¼����ɨ��") ;
		if (music.listFiles(new MusicFilter()).length > 0)
		{			
			for (File file : music.listFiles(new MusicFilter()))
			{
				mMusicList.add(file.getName());
			}
			Log.i("Sundy", "��������"+mMusicList.size()) ;
		
		}
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub		
		if(item.getItemId()==1)
			finish()  ;	
		else 
			startActivity(new Intent(this,VideoPlayActivity.class)) ;
		return true ;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
		menu.add(0,1,2,"�˳�") ;
		menu.add(0,2,1,"��Ӱ") ;
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		playerControl.release() ;
		mTimer.cancel()  ;
		if(notificationManager != null)
			notificationManager.cancel(123) ;
		Log.i("sundy", "released")  ;
		super.onDestroy();
	}
	
	
	//������������������
	private void updateSeekbar()
	{
		if(mTimer == null && mTimerTask == null)
		{
			mTimer = new Timer()  ;
			//ʱ������
			mTimerTask = new TimerTask() {
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					
					int curPoint = playerControl.mMediaPlayer.getCurrentPosition()  ;
					int totalPoint = playerControl.mMediaPlayer.getDuration()  ;
					
					mSeekBar.setProgress(curPoint*100/totalPoint) ;
				}
			};
			
			mTimer.schedule(mTimerTask, 0, 100)  ;
			
			//�϶��¼�ע��
			mSeekBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
				
				@Override
				public void onStopTrackingTouch(SeekBar arg0) {
					// TODO Auto-generated method stub
					int curPro = arg0.getProgress()  ;
					int totalPoint = playerControl.mMediaPlayer.getDuration()  ;
					
					playerControl.mMediaPlayer.seekTo(curPro*totalPoint/100)  ;
					
				}
				
				@Override
				public void onStartTrackingTouch(SeekBar arg0) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void onProgressChanged(SeekBar arg0, int arg1, boolean arg2) {
					// TODO Auto-generated method stub
					
				}
			})  ;
		}
	}

	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        mSeekBar = (SeekBar)findViewById(R.id.seekBar1) ;
        mListView = (ListView)findViewById(R.id.listView1)  ;
        imageButtonPlay =(ImageButton)findViewById(R.id.imageButtonPlay)  ;
        imageButtonNext = (ImageButton)findViewById(R.id.imageButtonNext) ;
        imageButtonPrev = (ImageButton)findViewById(R.id.imageButtonPrev)  ;
        
        imageButtonNext.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				playerControl.next() ;
			}
		}) ;
        
        imageButtonPrev.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				playerControl.prev() ;
			}
		}) ;
        
        imageButtonPlay.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if(playerControl == null)
					return  ;
				if(playerControl.getPlayerStatus()==3)
				{
					playerControl.pause()  ;
					imageButtonPlay.setImageResource(R.drawable.start)  ;
				}else
				{
					playerControl.start()  ;					
					imageButtonPlay.setImageResource(R.drawable.pause)  ;

					//������֮�� �� ����һ����̨�߳� �� ȥÿ��һ��ʱ�䣨100ms��ȥ��ȡ���Ž��� �� Ȼ��ѽ��ȸ��µ�seekBar
					//ȡ����ǰ���Ž��� 
					updateSeekbar() ;
				}
				
			}
		}) ;
        
        
        //���ö��̣߳��õ������ļ��б����ҽ��н������
        
        mListView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				//�õ�����ĸ�������
				playerControl.start(arg2)  ;
				imageButtonPlay.setImageResource(R.drawable.pause)  ;
				
			}
		}) ;
        
        mHandler = new Handler()
        {

			@Override
			public void handleMessage(Message msg) {
				// TODO Auto-generated method stub
				if(msg.what ==123)
				{
					//����listview����
					ListAdapter la = new ArrayAdapter<String>(SundyMp3PlayerActivity.this,android.R.layout.simple_list_item_1, mMusicList)  ;
					mListView.setAdapter(la)  ;
					
					playerControl = new PlayerControl(mMusicList, 0) ;
					playerControl.start(0)  ;
					updateSeekbar() ;
					imageButtonPlay.setImageResource(R.drawable.pause)  ;
				}
				super.handleMessage(msg);
			}
        	
        };
        
        new Thread(new Runnable()
        {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				getMusicList() ;
				if(mMusicList.size()>0)
					mHandler.sendEmptyMessage(123) ;
			}
        	
        }).start() ;
        
    }
}