package sundy.demo;

import java.io.IOException;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import android.media.MediaPlayer;
import android.media.MediaPlayer.OnPreparedListener;
import android.util.Log;
import android.widget.MediaController.MediaPlayerControl;

public class PlayerControl implements PlayerControlInterface,MediaPlayer.OnErrorListener{

	public MediaPlayer mMediaPlayer  ;
	public final String MUSIC_PATH = "/sdcard/sundymusic/" ;
	//���ֲ�������
	private int mMusicIndex = 0 ;
	private List mMusicList  ;
	//���ֵľ����ַ
	private String mMusicUrl  ;
	//0 �� idle , 1 , stop , 2 , pause  , 3 started
	private int mPlayerStatus = 0 ;
	public int getPlayerStatus() {
		return mPlayerStatus;
	}


	public void setPlayerStatus(int mPlayerStatus) {
		
		
	}
	
	
	//���캯��
	public PlayerControl(List<String> musicList,int musicIndex)
	{
		mMusicList = musicList  ;
		mMusicUrl = MUSIC_PATH + musicList.get(musicIndex) ;
		
		//ʵ��error
		//mMediaPlayer.setOnErrorListener(this)  ;
	}
	
	public void start(int musicIndex)
	{
		
		mMusicUrl = MUSIC_PATH + mMusicList.get(musicIndex) ;
		if(mMediaPlayer != null)
		{
			//mMediaPlayer.stop() ;
			mMediaPlayer.reset()  ;
			mPlayerStatus = 0 ;
		}	
		init()  ;
		
	}
	
	
	private void init()
	{
		if((mMediaPlayer == null && mMusicUrl != null) || mPlayerStatus ==0)
		{
			mMediaPlayer = new MediaPlayer() ;
			try {
				mMediaPlayer.setDataSource(mMusicUrl)  ;
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalStateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			mMediaPlayer.prepareAsync()  ;
			mMediaPlayer.setOnPreparedListener(new OnPreparedListener() {
				
				@Override
				public void onPrepared(MediaPlayer mp) {
					// TODO Auto-generated method stub
					mMediaPlayer.start()  ;
					mPlayerStatus = 3  ;
				}
			})  ;
		}
	}
	
	
	@Override
	public void start() {
		// TODO Auto-generated method stub
		if(mMediaPlayer == null)
		{
			init()  ;
		}else {
			if(mPlayerStatus == 1)
			{
				mMediaPlayer.prepareAsync()  ;
				mMediaPlayer.setOnPreparedListener(new OnPreparedListener() {
					
					@Override
					public void onPrepared(MediaPlayer mp) {
						// TODO Auto-generated method stub
						mMediaPlayer.start()  ;
						mPlayerStatus = 3  ;
					}
				})  ;
			}else if(mPlayerStatus ==2 && !mMediaPlayer.isPlaying())
			{
				mMediaPlayer.start()  ;
				mPlayerStatus = 3  ;
			}
			
		}
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub
		if(mMediaPlayer != null && mMediaPlayer.isPlaying())
		{
			mMediaPlayer.pause()  ;
			mPlayerStatus = 2  ;
		}
	}

	@Override
	public void next() {
		// TODO Auto-generated method stub
		if(mMusicIndex == (mMusicList.size()-1))
		{
			mMusicIndex = 0 ;
		}else {
			++mMusicIndex  ;
			
		}
		start(mMusicIndex)  ;
	}

	@Override
	public void prev() {
		// TODO Auto-generated method stub
		
		if(mMusicIndex == 0)
		{
			mMusicIndex = mMusicList.size()-1 ;
		}else {
			--mMusicIndex  ;
			
		}
		start(mMusicIndex)  ;
	}


	@Override
	public void release() {
		// TODO Auto-generated method stub
		if(mMediaPlayer != null)
		{
			if(mMediaPlayer.isPlaying())
				mMediaPlayer.stop() ;
			mMediaPlayer.release() ;
			mMediaPlayer = null ;
		}
	}


	@Override
	public boolean onError(MediaPlayer arg0, int arg1, int arg2) {
		// TODO Auto-generated method stub
		arg0.reset()  ;
		Log.i("sundy", "����error")  ;
		return false;
	}

}
