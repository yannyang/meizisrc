package sundy.demo;

import android.app.Activity;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

public class VideoPlayActivity extends Activity {

	private VideoView mVideoView  ;
	private MediaController mController  ;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.layout_videoplayer)  ;
		mVideoView = (VideoView)findViewById(R.id.videoView1) ;
		//mController = (MediaController)findViewById(R.id.mediaController1) ;
				
		mVideoView.setMediaController(new MediaController(this))  ;
		mVideoView.setVideoPath("/sdcard/UCDownloads/2.mp4")  ;
		mVideoView.start()  ;
	}

}
