package sundy.demo;

public interface PlayerControlInterface {
	public void start()  ;
	public void pause()  ;
	public void next()  ;
	public void prev()  ;
	public void release() ;
}
